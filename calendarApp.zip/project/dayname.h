#ifndef DAYNAME_H_INCLUDED
#define DAYNAME_H_INCLUDED

char* dayName(int day);

int zellersAlgorithm(int day, int month, int year);

#endif // DAYNAME_H_INCLUDED
